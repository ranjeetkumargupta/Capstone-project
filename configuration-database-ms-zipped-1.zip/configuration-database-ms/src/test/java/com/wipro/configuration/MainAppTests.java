package com.wipro.configuration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainAppTests {

	@Test
	void contextLoads() {
	}

}
